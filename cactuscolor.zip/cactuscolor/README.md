# Cactus Color (Fabric 1.21.4)

Клавиша **I** → палитра оттенков, справа вращающаяся мини-модель кактуса. Выбрал цвет — все кактусы в мире перекрашиваются. Цвет хранится в `config/cactuscolor.json`.

## Сборка
Нужна Java 21.
- Локально: `gradle wrapper --gradle-version 8.12` (один раз), затем `./gradlew build` → `build/libs/cactuscolor-1.0.0.jar`
- Или залей папку на GitHub: вкладка Actions → build → скачай jar из Artifacts.

## Установка
Fabric Loader 0.16.9+, Fabric API для 1.21.4, jar в папку `mods`.
