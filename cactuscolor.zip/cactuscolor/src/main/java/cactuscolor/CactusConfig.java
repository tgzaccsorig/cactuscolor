package cactuscolor;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Хранит выбранный цвет кактуса (RGB) в config/cactuscolor.json. */
public final class CactusConfig {
	public static final int DEFAULT_COLOR = 0x5EA832;

	/** Текущий цвет в формате 0xRRGGBB. */
	public static int color = DEFAULT_COLOR;

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private CactusConfig() {
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("cactuscolor.json");
	}

	public static void load() {
		Path f = file();
		if (!Files.exists(f)) {
			return;
		}
		try {
			JsonObject obj = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
			if (obj.has("color")) {
				color = obj.get("color").getAsInt() & 0xFFFFFF;
			}
		} catch (Exception e) {
			System.err.println("[CactusColor] Не удалось прочитать конфиг: " + e);
		}
	}

	public static void save() {
		JsonObject obj = new JsonObject();
		obj.addProperty("color", color & 0xFFFFFF);
		obj.addProperty("hex", String.format("#%06X", color & 0xFFFFFF));
		try {
			Files.writeString(file(), GSON.toJson(obj));
		} catch (IOException e) {
			System.err.println("[CactusColor] Не удалось сохранить конфиг: " + e);
		}
	}
}
