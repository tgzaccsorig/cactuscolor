package cactuscolor;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.text.Text;
import org.joml.Matrix4f;

import java.awt.Color;

/** Экран палитры: слева сетка оттенков, справа вращающаяся мини-модель кактуса. */
public class CactusColorScreen extends Screen {
	private static final int COLS = 12;
	private static final int CELL = 16;
	private static final int GAP = 2;
	private static final int STEP = CELL + GAP;

	// пары (насыщенность, яркость) для рядов палитры; последний ряд — оттенки серого
	private static final float[][] ROWS = {
			{0.25f, 1.0f}, {0.50f, 1.0f}, {0.75f, 1.0f}, {1.0f, 1.0f},
			{1.0f, 0.80f}, {1.0f, 0.60f}, {1.0f, 0.40f}
	};
	private static final int TOTAL_ROWS = ROWS.length + 1;

	private static final int PALETTE_W = COLS * STEP - GAP;
	private static final int PALETTE_H = TOTAL_ROWS * STEP - GAP;
	private static final int PREVIEW_W = 100;
	private static final int PAD = 14;
	private static final int PANEL_W = PAD + PALETTE_W + PAD + PREVIEW_W + PAD;
	private static final int PANEL_H = 36 + PALETTE_H + 12 + 20 + PAD;

	private int panelX, panelY;
	private int palX, palY;
	private int prevX, prevY, prevH;

	private final int startColor = CactusConfig.color;
	private float dragYaw = 0f;

	public CactusColorScreen() {
		super(Text.translatable("screen.cactuscolor.title"));
	}

	@Override
	protected void init() {
		panelX = (this.width - PANEL_W) / 2;
		panelY = (this.height - PANEL_H) / 2;
		palX = panelX + PAD;
		palY = panelY + 36;
		prevX = palX + PALETTE_W + PAD;
		prevY = palY;
		prevH = PALETTE_H;

		int btnY = palY + PALETTE_H + 12;
		int btnW = (PALETTE_W - 6) / 2;
		this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.cactuscolor.reset"),
				b -> CactusConfig.color = CactusConfig.DEFAULT_COLOR)
				.dimensions(palX, btnY, btnW, 20).build());
		this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.cactuscolor.done"),
				b -> this.close())
				.dimensions(palX + btnW + 6, btnY, btnW, 20).build());
	}

	/** Цвет ячейки палитры (RGB). */
	private static int cellColor(int col, int row) {
		if (row < ROWS.length) {
			return Color.HSBtoRGB(col / (float) COLS, ROWS[row][0], ROWS[row][1]) & 0xFFFFFF;
		}
		int g = Math.round(255f * (1f - col / (float) (COLS - 1)));
		return (g << 16) | (g << 8) | g;
	}

	// ---------------------------------------------------------------- рисование

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.renderBackground(ctx, mouseX, mouseY, delta);
		// рамка и фон панели
		ctx.fill(panelX - 2, panelY - 2, panelX + PANEL_W + 2, panelY + PANEL_H + 2, 0xFF000000);
		ctx.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, 0xFF2B2B2B);
		// фон окна предпросмотра
		ctx.fill(prevX - 1, prevY - 1, prevX + PREVIEW_W + 1, prevY + prevH + 1, 0xFF000000);
		ctx.fill(prevX, prevY, prevX + PREVIEW_W, prevY + prevH, 0xFF8FC7E8);
		ctx.fill(prevX, prevY + prevH - 30, prevX + PREVIEW_W, prevY + prevH, 0xFF6FA8CB);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta); // фон + кнопки

		ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, panelX + PANEL_W / 2, panelY + 10, 0xFFFFFF);
		ctx.drawTextWithShadow(this.textRenderer,
				Text.literal(String.format("#%06X", CactusConfig.color & 0xFFFFFF)),
				palX, panelY + 22, 0xFFDDDDDD);

		// палитра
		int hoverCol = -1, hoverRow = -1;
		for (int r = 0; r < TOTAL_ROWS; r++) {
			for (int c = 0; c < COLS; c++) {
				int x = palX + c * STEP;
				int y = palY + r * STEP;
				int rgb = cellColor(c, r);
				boolean selected = rgb == (CactusConfig.color & 0xFFFFFF);
				boolean hovered = mouseX >= x && mouseX < x + CELL && mouseY >= y && mouseY < y + CELL;
				if (hovered) {
					hoverCol = c;
					hoverRow = r;
				}
				if (selected) {
					ctx.fill(x - 2, y - 2, x + CELL + 2, y + CELL + 2, 0xFFFFFFFF);
					ctx.fill(x - 1, y - 1, x + CELL + 1, y + CELL + 1, 0xFF000000);
				} else if (hovered) {
					ctx.fill(x - 1, y - 1, x + CELL + 1, y + CELL + 1, 0xFFAAAAAA);
				}
				ctx.fill(x, y, x + CELL, y + CELL, 0xFF000000 | rgb);
			}
		}

		// подпись под превью
		ctx.drawCenteredTextWithShadow(this.textRenderer, Text.translatable("screen.cactuscolor.hint"),
				prevX + PREVIEW_W / 2, prevY - 11, 0xFFAAAAAA);

		// 3D-модель
		ctx.draw(); // сбросить накопленные GUI-вершины, чтобы порядок рисования был верным
		float yaw = dragYaw + (System.currentTimeMillis() % 20000L) / 20000f * (float) (Math.PI * 2);
		drawCactus(ctx, prevX + PREVIEW_W / 2f, prevY + prevH / 2f + 6, 52f, yaw, CactusConfig.color);
	}

	// ------------------------------------------------------------------ модель

	// коробки: x0,y0,z0, x1,y1,z1, тип (0 = кактус, 1 = песок)
	private static final float[][] BOXES = {
			{-0.80f, -0.30f, -0.80f, 0.80f, 0.00f, 0.80f, 1},     // блок песка
			{-0.22f, 0.00f, -0.22f, 0.22f, 1.35f, 0.22f, 0},      // ствол
			{-0.56f, 0.48f, -0.14f, -0.20f, 0.76f, 0.14f, 0},     // левая рука (горизонтально)
			{-0.56f, 0.48f, -0.14f, -0.30f, 1.05f, 0.14f, 0},     // левая рука (вверх)
			{0.20f, 0.30f, -0.14f, 0.54f, 0.58f, 0.14f, 0},       // правая рука (горизонтально)
			{0.28f, 0.30f, -0.14f, 0.54f, 0.82f, 0.14f, 0},       // правая рука (вверх)
	};
	private static final float MODEL_CENTER_Y = 0.5f;

	private static final float PITCH = 0.38f;

	private void drawCactus(DrawContext ctx, float cx, float cy, float scale, float yaw, int cactusRgb) {
		Matrix4f m = ctx.getMatrices().peek().getPositionMatrix();

		RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
		RenderSystem.enableDepthTest();
		RenderSystem.depthFunc(515); // GL_LEQUAL
		RenderSystem.disableCull();

		BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

		float cosY = (float) Math.cos(yaw), sinY = (float) Math.sin(yaw);
		float cosP = (float) Math.cos(PITCH), sinP = (float) Math.sin(PITCH);

		for (float[] b : BOXES) {
			int rgb = b[6] == 0 ? cactusRgb : 0xD9C58A;
			boolean cactus = b[6] == 0;
			float x0 = b[0], y0 = b[1] - MODEL_CENTER_Y, z0 = b[2], x1 = b[3], y1 = b[4] - MODEL_CENTER_Y, z1 = b[5];
			float dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
			// грани: нормаль, угол, вектор u, вектор v
			float[][] faces = {
					{0, 1, 0, x0, y1, z0, dx, 0, 0, 0, 0, dz},   // верх
					{0, 0, 1, x0, y0, z1, dx, 0, 0, 0, dy, 0},   // +z
					{0, 0, -1, x0, y0, z0, dx, 0, 0, 0, dy, 0},  // -z
					{1, 0, 0, x1, y0, z0, 0, 0, dz, 0, dy, 0},   // +x
					{-1, 0, 0, x0, y0, z0, 0, 0, dz, 0, dy, 0},  // -x
			};
			for (int i = 0; i < faces.length; i++) {
				float[] f = faces[i];
				float[] n = rotate(f[0], f[1], f[2], cosY, sinY, cosP, sinP);
				if (n[2] <= 0.02f) {
					continue; // грань смотрит от нас
				}
				float light = 0.45f + 0.55f * Math.max(0f, n[0] * 0.35f + n[1] * 0.80f + n[2] * 0.45f);
				// для боковых граней кактуса рисуем 3 вертикальные полосы — «рёбра»
				int stripes = (cactus && i != 0) ? 3 : 1;
				for (int s = 0; s < stripes; s++) {
					float k = stripes == 1 ? 1f : (s == 1 ? 1.0f : 0.82f);
					int r = clamp(((rgb >> 16) & 255) * light * k);
					int g = clamp(((rgb >> 8) & 255) * light * k);
					int bl = clamp((rgb & 255) * light * k);
					float t0 = s / (float) stripes, t1 = (s + 1) / (float) stripes;
					quad(buf, m, cx, cy, scale, f, t0, t1, cosY, sinY, cosP, sinP, r, g, bl);
				}
			}
		}

		BufferRenderer.drawWithGlobalProgram(buf.end());
		RenderSystem.enableCull();
	}

	private static void quad(BufferBuilder buf, Matrix4f m, float cx, float cy, float scale, float[] f,
							 float t0, float t1, float cosY, float sinY, float cosP, float sinP, int r, int g, int b) {
		float ox = f[3], oy = f[4], oz = f[5];
		float ux = f[6], uy = f[7], uz = f[8];
		float vx = f[9], vy = f[10], vz = f[11];
		float[][] pts = {
				{ox + ux * t0, oy + uy * t0, oz + uz * t0},
				{ox + ux * t1, oy + uy * t1, oz + uz * t1},
				{ox + ux * t1 + vx, oy + uy * t1 + vy, oz + uz * t1 + vz},
				{ox + ux * t0 + vx, oy + uy * t0 + vy, oz + uz * t0 + vz},
		};
		for (float[] p : pts) {
			float[] q = rotate(p[0], p[1], p[2], cosY, sinY, cosP, sinP);
			buf.vertex(m, cx + q[0] * scale, cy - q[1] * scale, 150f + q[2] * scale).color(r, g, b, 255);
		}
	}

	/** Поворот вокруг Y, затем наклон вокруг X (камера смотрит чуть сверху). */
	private static float[] rotate(float x, float y, float z, float cosY, float sinY, float cosP, float sinP) {
		float x1 = x * cosY + z * sinY;
		float z1 = -x * sinY + z * cosY;
		float y2 = y * cosP - z1 * sinP;
		float z2 = y * sinP + z1 * cosP;
		return new float[]{x1, y2, z2};
	}

	private static int clamp(float v) {
		return Math.max(0, Math.min(255, Math.round(v)));
	}

	// ------------------------------------------------------------------- ввод

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button == 0) {
			for (int r = 0; r < TOTAL_ROWS; r++) {
				for (int c = 0; c < COLS; c++) {
					int x = palX + c * STEP;
					int y = palY + r * STEP;
					if (mouseX >= x && mouseX < x + CELL && mouseY >= y && mouseY < y + CELL) {
						CactusConfig.color = cellColor(c, r);
						return true;
					}
				}
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
		if (button == 0 && mouseX >= prevX && mouseX < prevX + PREVIEW_W && mouseY >= prevY && mouseY < prevY + prevH) {
			dragYaw += (float) deltaX * 0.03f;
			return true;
		}
		return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (CactusColorClient.openKey != null && CactusColorClient.openKey.matchesKey(keyCode, scanCode)) {
			this.close();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public void removed() {
		CactusConfig.save();
		// перерисовать чанки, если цвет изменился
		if (CactusConfig.color != startColor && this.client != null && this.client.worldRenderer != null) {
			this.client.worldRenderer.reload();
		}
	}
}
