package cactuscolor;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.block.Blocks;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class CactusColorClient implements ClientModInitializer {
	public static KeyBinding openKey;

	@Override
	public void onInitializeClient() {
		CactusConfig.load();

		openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.cactuscolor.open",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_I,
				"category.cactuscolor"
		));

		// Модель кактуса (assets/minecraft/blockstates/cactus.json) использует tintindex 0,
		// здесь отдаём ей выбранный игроком цвет.
		ColorProviderRegistry.BLOCK.register((state, view, pos, tintIndex) -> CactusConfig.color, Blocks.CACTUS);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openKey.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new CactusColorScreen());
				}
			}
		});
	}
}
